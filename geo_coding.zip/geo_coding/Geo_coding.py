# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication,QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction,QMessageBox,QFileDialog

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .Geo_coding_dialog import GeoCodingDialog
import os.path


import math
import os
from qgis.core import (
    QgsNominatimGeocoder,
    QgsGeocoderContext,
    QgsCoordinateTransformContext,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsField,
    QgsProject,
    QgsGeocoderInterface
)



class GeoCoding:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):

        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'GeoCoding_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&GeoCoding')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

    # noinspection PyMethodMayBeStatic

    def Geo_coding_excel(self,uri):

        def Tran_WGS_to_ISR(longitude,latitude):

            def degreesToRadians(degrees):
                return degrees * math.pi / 180
            def pow2(x):
                return pow(x, 2)
            def pow3(x):
                return pow(x, 3)
            def pow4(x):
                return pow(x, 4)

            longitude       = degreesToRadians(longitude)
            latitude        = degreesToRadians(latitude)
            centralMeridian = degreesToRadians(35.2045169444444);  # central meridian of ITM projection
            k0              = 1.0000067;  # scale factor

            # Ellipsoid constants (WGS 80 datum)

            a    = 6378137      #equatorial radius
            b    = 6356752.3141 # polar radius
            e    = math.sqrt(1 - b*b/a/a);  ## eccentricity
            e1sq = e*e/(1-e*e)
            n    = (a-b)/(a+b)

            tmp = e*math.sin(latitude)
            nu  = a/math.sqrt(1 - tmp*tmp)

            ## Meridional arc length

            n3 = pow3(n)
            n4 = pow4(n)

            A0 = a*(1-n+(5*n*n/4)*(1-n) +(81*n4/64)*(1-n))
            B0 = (3*a*n/2)*(1 - n - (7*n*n/8)*(1-n) + 55*n4/64)
            C0 = (15*a*n*n/16)*(1 - n +(3*n*n/4)*(1-n))
            D0 = (35*a*n3/48)*(1 - n + 11*n*n/16)
            E0 = (315*a*n4/51)*(1-n)

            S = A0*latitude - B0*math.sin(2*latitude) + C0*math.sin(4*latitude)- D0*math.sin(6*latitude) + E0*math.sin(8*latitude);

            ## Coefficients for ITM coordinates

            p    = longitude-centralMeridian
            Ki   = S*k0
            Kii  = nu*math.sin(latitude)*math.cos(latitude)*k0/2
            Kiii = ((nu*math.sin(latitude)*pow3(math.cos(latitude)))/24)*(5-pow2(math.tan(latitude))+9*e1sq*pow2(math.cos(latitude))+4*e1sq*e1sq*pow4(math.cos(latitude)))*k0;
            Kiv  = nu*math.cos(latitude)*k0
            Kv   = pow3(math.cos(latitude))*(nu/6)*(1-pow2(math.tan(latitude))+e1sq*pow2(math.cos(latitude)))*k0;

            easting  = round(219529.58+ Kiv*p+Kv*pow3(p) - 60)
            northing = round(Ki+Kii*p*p+Kiii*pow4(p) - 3512424.41+ 626907.39 - 45)

            return easting,northing

        def GeoCoding(address):
            n       = QgsNominatimGeocoder()
            context = QgsGeocoderContext(QgsCoordinateTransformContext())
            out     = n.geocodeString(address, context)
            getter_methods_geocoder_result = ['crs','geometry','description']

            return {method: getattr(f, method)() for f in out for method in getter_methods_geocoder_result}

        def ReadExcel(uri):
            layer = QgsVectorLayer(uri, 'test', 'ogr')
            field = layer.fields()[0].name()
            return [feat[field] for feat in layer.getFeatures()]


        def Create_mask_layer(data_list,crs):
            if not data_list:
                return 
            vl = QgsVectorLayer(str('Point?crs='+crs), "point", "memory")
            pr      = vl.dataProvider()
            # add fields
            pr.addAttributes([QgsField("x", QVariant.String),\
                            QgsField("y", QVariant.String),\
                            QgsField("adress", QVariant.String)])
            vl.updateFields() # tell the vector layer to fetch changes from the provid
            QgsProject.instance().addMapLayer(vl)
            fet   = QgsFeature()
            for i in data_list:
                fet.setGeometry(i[0])
                fet.setAttributes(i[1:])
                pr.addFeatures([fet])
            vl.updateExtents()


        def OpenSource(uri):
            address     = ReadExcel(uri)
            featureList = []
            didnt_find  = []
            for i in address:
                try:
                    dict_adress   = GeoCoding(i)
                    geometryPoint = dict_adress['geometry'].asPoint()
                    x,y = Tran_WGS_to_ISR(geometryPoint.x(),geometryPoint.y())
                    PointGeom = QgsGeometry.fromPointXY(QgsPointXY(x,y))
                    featureList.append([PointGeom,x,y,i])
                except:
                    didnt_find.append(i)

            if didnt_find:
                didnt_find = ''.join([i for i in str(didnt_find) if i not in ('[',']')])
                QMessageBox.information(self.dlg,'Message',"Coudnt find: {}".format(didnt_find))

                    # featureList.append([dict_adress['geometry'],geometryPoint.x(),geometryPoint.y(),i])

            Create_mask_layer(featureList,crs = '2039')

        OpenSource(uri)


    def tr(self, message):

        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('GeoCoding', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):


        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/Geo_coding/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'GeoCode'),
            callback=self.run,
            parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&GeoCoding'),
                action)
            self.iface.removeToolBarIcon(action)


    def run(self):

        """Run method that performs all the real work"""

        # Create the dialog with elements (after translation) and keep reference
        # Only create GUI ONCE in callback, so that it will only load when the plugin is started
        if self.first_start == True:
            self.first_start = False
            self.dlg = GeoCodingDialog()

            # QMessageBox.information(self.dlg,'Message',"should only run once")

        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed

        csv_path = QFileDialog.getOpenFileName()[0]

        if result:
            # QMessageBox.information(self.dlg,'Message',self.dlg.lineEdit.text())
            # excel = self.dlg.lineEdit.text()

            # if excel:
            #     self.Geo_coding_excel(excel)
            #     QMessageBox.information(self.dlg,'Message','Done')

            # lyr_csv    = self.dlg.mMapLayerComboBox.currentLayer()
            # csv_path   = str(lyr_csv.dataProvider().dataSourceUri())


            QMessageBox.information(self.dlg,'Message',csv_path)
            self.Geo_coding_excel(csv_path)

        else:
            QMessageBox.information(self.dlg,'Message',"Canceld")



# uri         = r"C:\Users\Administrator\Desktop\medad\python\Qgis\GeoCoding\address.xlsx"

